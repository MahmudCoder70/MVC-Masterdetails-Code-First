﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Masterdetails_Mvc.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }

        public ICollection<BookingEntry> BookingEntries { get; set; } = new List<BookingEntry>();
    }
}